﻿using Azure.Storage.Queues;

namespace CLVD3.Services
{
    //    Author: Mick Gouweloos
    //Link: https://github.com/mickymouse777/Cloud_Storage/tree/master/Cloud_Storage
    // Accessed: 8 November 2024
    public class QueueService
    {
        private readonly string _connectionString;

        public QueueService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task SendMessageAsync(string queueName, string message)
        {
            // Create a QueueClient for the specified queue
            var queueClient = new QueueClient(_connectionString, queueName);

            await queueClient.CreateIfNotExistsAsync();

            await queueClient.SendMessageAsync(message);
        }
    }
}