﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace CLVD3.Services
{
    //    Author: Mick Gouweloos
    //Link: https://github.com/mickymouse777/Cloud_Storage/tree/master/Cloud_Storage
    // Accessed: 8 November 2024
    public class BlobService
    {     // The _blobServiceClient field holds an instance of BlobServiceClient,
        private readonly BlobServiceClient _blobServiceClient;

        // The _containerName field specifies the name of the blob container where the files will be uploaded.
        private readonly string _containerName = "products";

        // This connection string is used to instantiate the BlobServiceClient, enabling access to the Blob Storage account.
        public BlobService(string connectionString)
        {
            // Initializes the _blobServiceClient with the provided connection string.
            _blobServiceClient = new BlobServiceClient(connectionString);
        }

        // The UploadAsync method uploads a file to the blob container asynchronously.
        public async Task<string> UploadAsync(Stream fileStream, string fileName)
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);

            var blobClient = containerClient.GetBlobClient(fileName);

            await blobClient.UploadAsync(fileStream);

            return blobClient.Uri.ToString();
        }

        // The DeleteBlobAsync method deletes a specified blob from the blob container asynchronously.
        // It takes the URI of the blob as a parameter.
        public async Task DeleteBlobAsync(string blobUri)
        {
            Uri uri = new Uri(blobUri);

            string blobName = uri.Segments[^1];

            var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);

            var blobClient = containerClient.GetBlobClient(blobName);

            await blobClient.DeleteIfExistsAsync(DeleteSnapshotsOption.IncludeSnapshots);
        }
    }
}
