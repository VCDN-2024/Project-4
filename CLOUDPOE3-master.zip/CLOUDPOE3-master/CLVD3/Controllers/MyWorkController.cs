﻿using CLVD3.Data;
using CLVD3.Models;
using CLVD3.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CLVD3.Controllers
{
    
    public class MyWorkController : Controller
    {
        private readonly ApplicationDBContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly QueueService _queueService;

        public MyWorkController(ApplicationDBContext context, UserManager<IdentityUser> userManager, QueueService queueService)
        {
            _context = context; 
            _userManager = userManager; 
            _queueService = queueService;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Product.ToListAsync());  
        }


        // Adds a new order for a specified product if it is available and the user does not already have an open order.
        [HttpPost]
        public async Task<IActionResult> CreateOrder(int productId)
        {
            var user = await _userManager.GetUserAsync(User);
            var userId = await _userManager.GetUserIdAsync(user);


            var product = _context.Product.FirstOrDefault(p => p.ProductId == productId && p.Availability == true);

            // Checks for an existing open order with "Shopping" status for this user.
            var openOrder = await _context.Orders
                .FirstOrDefaultAsync(o => o.UserId == userId && o.Status == "Shopping");

            if (openOrder == null)
            {
                openOrder = new Order
                {
                    UserId = userId,
                    OrderDate = DateTime.Now,
                    Status = "Shopping"
                };
                _context.Orders.Add(openOrder);
                await _context.SaveChangesAsync();
            }

            var orderRequest = new OrderPlaced
            {
                OrderId = openOrder.OrderId,
                ProductId = productId,
                OrderStatus = "Pending"
            };
            _context.Requests.Add(orderRequest);

            // Marks the product as unavailable to reflect its addition to the order.
            product.Availability = false;

            await _context.SaveChangesAsync();

            return Json(new { success = true }); 
        }


        public async Task<IActionResult> Cart()
        {
            var user = await _userManager.GetUserAsync(User);
            var userId = await _userManager.GetUserIdAsync(user);

            var openOrder = await _context.Orders
                .Include(o => o.Requests)
                .ThenInclude(or => or.Product)
                .FirstOrDefaultAsync(o => o.UserId == userId && o.Status == "Shopping");

            return View(openOrder);
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFromCart(int productId)
        {
            var user = await _userManager.GetUserAsync(User);
            var userId = await _userManager.GetUserIdAsync(user);
            var openOrder = await _context.Orders
                .Include(o => o.Requests)
                .FirstOrDefaultAsync(o => o.UserId == userId && o.Status == "Shopping");

            if (openOrder != null)
            {
                var orderRequest = openOrder.Requests
                    .FirstOrDefault(or => or.ProductId == productId);

                if (orderRequest != null)
                {
                    _context.Requests.Remove(orderRequest);

                    // Restores the product’s availability to "In Stock".
                    var product = await _context.Product.FindAsync(productId);
                    if (product != null)
                    {
                        product.Availability = true;
                    }

                    await _context.SaveChangesAsync();

                    return Json(new { success = true });
                }
            }

            return Json(new { success = false, message = "Item not found in cart" });
        }

        [HttpPost]
        public async Task<IActionResult> Checkout(decimal totalPrice)
        {
            var user = await _userManager.GetUserAsync(User);
            var userId = await _userManager.GetUserIdAsync(user);

            var openOrder = await _context.Orders
                .Include(o => o.Requests)
                .FirstOrDefaultAsync(o => o.UserId == userId && o.Status == "Shopping");

            if (openOrder == null || !openOrder.Requests.Any())
            {
                return Json(new { success = false, message = "No items" });
            }

            
            openOrder.TotalPrice = totalPrice;
            openOrder.Status = "Pending";
            await _context.SaveChangesAsync();

            // Send a message to the queue
            string message = $" Order: Order ID: {openOrder.OrderId} added succesfully on Order Date: {openOrder.OrderDate} by User: {openOrder.User} values at Total Price: R {openOrder.TotalPrice} with the Status: {openOrder.Status}";
            await _queueService.SendMessageAsync("createdorders", message);

            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult CheckProductAvailability(int productId)
        {
            var product = _context.Product.FirstOrDefault(p => p.ProductId == productId && p.Availability == true);

            if (product != null)
            {
               return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Product is not available" });
            }
        }
    }
}
