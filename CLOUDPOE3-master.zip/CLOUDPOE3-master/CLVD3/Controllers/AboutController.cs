﻿  using Microsoft.AspNetCore.Mvc;

namespace CLVD3.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
