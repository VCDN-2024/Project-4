﻿namespace CLVD3.Models
{
    public class OrderPlaced
    {  // The OrderRequestId property serves as the unique identifier for each order request.
        public int OrderPlacedId { get; set; }

        // The OrderId property links the order request to the corresponding order.
        public int OrderId { get; set; }

        // The ProductId property identifies the specific product that is being requested in this order.
        public int ProductId { get; set; }

        // The OrderStatus property indicates the current status of the order request.
        public string? OrderStatus { get; set; }

        // The Order property is a navigation property that creates a relationship between the OrderRequest and its associated Order.
        public virtual Order Order { get; set; } = null!;

        // The Product property is a navigation property that links the order request to the corresponding Product.
        public virtual Product Product { get; set; } = null!;
    }
}
