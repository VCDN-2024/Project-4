﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CLVD3.Models
{
    public class Order
    {// Defines the Order class, which represents an order placed by a user in the retail application.
        public int OrderId { get; set; }

        // The UserId property holds the unique identifier for the user who placed the order.
        public string UserId { get; set; }

        // The OrderDate property records the date and time when the order was placed.
        public DateTime OrderDate { get; set; }

        // The Status property indicates the current status of the order (e.g., "Pending," "Shipped," "Completed").
        public string? Status { get; set; }

        // The TotalPrice property holds the total amount for the order.
        public decimal? TotalPrice { get; set; }

        // The OrderRequests property is a collection that holds all OrderRequest instances associated with the Order.
        public virtual ICollection<OrderPlaced> Requests { get; set; } = new List<OrderPlaced>();

        // The User property establishes a foreign key relationship to the ApplicationUser class.
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; }
    }
}
