﻿using System.ComponentModel.DataAnnotations;

namespace CLVD3.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        // The Name property stores the name of the product.
        public string? Name { get; set; }

        // The ProductDescription property holds a detailed description of the product.
        public string? ProductDescription { get; set; }

        // The Price property indicates the cost of the product.
        [DisplayFormat(DataFormatString = "{0:C}", ApplyFormatInEditMode = false)]
        public decimal? Price { get; set; }

        // The Category property categorizes the product.
        public string? Category { get; set; }

        // The Availability property indicates whether the product is available for purchase.
        public bool? Availability { get; set; }

        // The ImageUrlpath property stores the URL path to the product's image.
        public string? ImageUrlpath { get; set; }
    }
}
