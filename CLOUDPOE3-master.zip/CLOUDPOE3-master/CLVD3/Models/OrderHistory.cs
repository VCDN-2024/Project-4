﻿namespace CLVD3.Models
{
    public class OrderHistory
    {
        // The OrderId property serves as a unique identifier for each order in the user's order history.
        public int OrderId { get; set; }

        // The OrderDate property records the date and time when the order was placed.
        public DateTime OrderDate { get; set; }

        // The Status property indicates the current processing status of the order, such as "Pending," "Shipped," or "Delivered."
        public string Status { get; set; }

        // The TotalPrice property represents the total cost of the order.
        public decimal TotalPrice { get; set; }
    }
}
