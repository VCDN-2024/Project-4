﻿namespace CLVD3.Models
{
    public class AdminVM
    { 
        // The OrderId property uniquely identifies each order.
        public int OrderId { get; set; }

        // The OrderDate property captures the date and time when the order was placed.
        public DateTime OrderDate { get; set; }

        // The UserEmail property stores the email address of the user who placed the order.
        public string UserEmail { get; set; }

        // The Status property indicates the current processing status of the order (e.g., "Pending," "Shipped," "Completed").
        public string? Status { get; set; }

        // The TotalPrice property represents the total cost of the order.
        public decimal TotalPrice { get; set; }
    }
}
