﻿using System.ComponentModel.DataAnnotations;

namespace CLVD3.Models
{
    public class Document
    {
        // The Id property serves as a unique identifier for each Document instance.
        public int Id { get; set; }

        // The Title property holds the title of the document.
        [Required(ErrorMessage = "The Title field is required.")]
        public string Title { get; set; }

        // The Description property provides a textual description of the document.
        [Required(ErrorMessage = "The Description field is required.")]
        public string Description { get; set; }

        // The FilePath property stores the path where the document file is located.
        [Required(ErrorMessage = "The FilePath field is required.")]
        public string FilePath { get; set; } // Changed from FileName to FilePath

        // The UploadDate property records the date and time when the document was uploaded.
        public DateTime UploadDate { get; set; }
    }
}
