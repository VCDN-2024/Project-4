﻿//
using CLVD3.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CLVD3.Data
{
    public class ApplicationDBContext : IdentityDbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
            : base(options)
        {
        }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        public DbSet<Product> Product { get; set; }

        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderPlaced> Requests { get; set; }
        public DbSet<Document> Documents { get; set; }

    }
}
